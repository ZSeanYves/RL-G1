# Aloha XM540

[XM540-W270-T](https://emanual.robotis.com/docs/en/dxl/x/xm540-w270/)

[XM430-W350-T](https://emanual.robotis.com/docs/en/dxl/x/xm430-w350/)

## SDK

https://emanual.robotis.com/docs/en/software/dynamixel/dynamixel_sdk/overview/

https://github.com/ROBOTIS-GIT/DynamixelSDK/releases


# 加减速配置
https://emanual.robotis.com/docs/en/dxl/x/xm430-w350/#reference