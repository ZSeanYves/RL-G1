# Aloha Motor Service

使用Aloha官方电机搭建的机械臂

底层服务进行串口通信，对外提供dds接口