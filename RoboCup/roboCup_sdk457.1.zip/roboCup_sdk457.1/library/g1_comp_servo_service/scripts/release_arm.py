from unitree_dl_utils.robots.aloha.aloha import AlohaCtrl

aloha = AlohaCtrl("aloha")
aloha.enable(1)
aloha.enable(0)
